package com.assignment;

import java.util.Scanner;

public class Evennumbers {
 public static void main(String[] args) {
	 int n;
	 System.out.println("enter n value");
	 Scanner sc=new Scanner(System.in);
	 n=sc.nextInt();
	 System.out.println("All Even numbers before " + n);
	 for(int i=1;i<=n;i++)
	 {
		 if(i%2==0) {
			 System.out.println(i);
		 }
	 }
}
}
