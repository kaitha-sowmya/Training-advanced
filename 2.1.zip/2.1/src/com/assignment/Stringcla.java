package com.assignment;

public class Stringcla {
	
	public static void main(String[] args) {
	    int totalargs, argLen;
	    int length=0;
	    String str="";
	    totalargs = args.length; 
	    System.out.println("number of arguments:"+totalargs);
	    for(int i=0; i<totalargs; i++)
	    {
	        argLen = args[i].length();
	        length=length+argLen; 
	    }
	    System.out.println("Length of string:"+length);
	    for(int i=0; i<totalargs; i++) {
	    	str=str.concat(args[i].toUpperCase());
	    }
	    System.out.println("string to uppercase:"+str);
	    String reverse=new StringBuffer(str).reverse().toString();
	    if(str.equals(reverse)) {
	    	System.out.println(str +" is a palindrome");
	    }
	    else {
	    	System.out.println(str + " is not a palindrome");
	    }
	}
	}

