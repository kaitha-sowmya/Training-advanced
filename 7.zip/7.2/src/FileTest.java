

	import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;
class Student implements Serializable{
     String name;
     int age;
     int rollnumber;
     String address;
	public Student(String name, int age, int rollnumber, String address) {
		super();
		this.name = name;
		this.age = age;
		this.rollnumber = rollnumber;
		this.address = address;
	}
     
	}
class FileTest{
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter student name");
		String sname=sc.next();
		System.out.println("enter student age");
		int sage=sc.nextInt();
		System.out.println("enter student rollname");
		int rollno=sc.nextInt();
		System.out.println("enter student address");
		String saddress=sc.next();
		Student object = new Student(sname,sage,rollno,saddress);
        String filename = "a.txt";
          
       
        try
        {   
            
            FileOutputStream file = new FileOutputStream(filename);
            ObjectOutputStream out = new ObjectOutputStream(file);
              
            // Method for serialization of object
           System.out.println("Do you want to write to file?true or false");
           Boolean temp=sc.nextBoolean();
           if(temp=true) {
           out.writeObject(object);
              
            out.close();
            file.close();
           
            System.out.println("Object has been added");
           }
           else {
        	   System.exit(0);
           }
        }
          
        catch(IOException ex)
        {
            System.out.println("IOException is caught");
        }
	}
}


