import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class Main{
	
	static String filename = "f.txt";

public static void main(String[] args) throws IOException, ClassNotFoundException {
	HashSet<Product> set = new HashSet<Product>();
	//ArrayList<Product> list1 = new ArrayList<>();
	
	
	Scanner sc=new Scanner(System.in);
	System.out.println("enetr number of products");
	int n=sc.nextInt();
	for(int i=0;i!=n;i++)
	{
		
	System.out.println("enter product id:");
	int id=sc.nextInt();
	System.out.println("enter product Name:");
	String name=sc.next();
	Product p=new Product(id,name);
	set.add(p);
}
	for(Product p1:set) {
	System.out.println(p1);
	}
	
	 Iterator hashSetIterator = set.iterator();
//	    while(hashSetIterator.hasNext()){
//	        System.out.println(hashSetIterator.next());
//	    }
	    ObjectOutputStream writer = new ObjectOutputStream(new FileOutputStream("f.txt"));
	    while(hashSetIterator.hasNext()){
	        Object o = hashSetIterator.next();
	        writer.writeObject(o);   
	    }
	    System.out.println("serialised");
	    Iterator read = set.iterator();
//	    while(read.hasNext()){
//	        System.out.println(read.next());
//	    }
	    ObjectInputStream print = new ObjectInputStream(new FileInputStream("f.txt"));
	    while(read.hasNext()){
	        Product p = (Product)read.next();
	        print.readObject();
	       
	        System.out.println(p.productId+" "+p.productName);
	    }
	    
	    
	
}


}
