package com.assignment;

public class TestInstrument {

		public static void main(String[] args) {
			
			Instrument ins;
			Piano p =new Piano();
			Guitar g =new Guitar();
			Flute f=new Flute();
			Instrument[] instrument = new Instrument[10];
			for(int i=1;i<=instrument.length;i++){
				ins=p;ins.play();
				System.out.println(p instanceof Piano);
				i++;ins=g;
				ins.play();
				System.out.println(g instanceof Guitar);
				i++;ins=f;
				ins.play();
				System.out.println(f instanceof Flute);
	            	}
		}

	}

