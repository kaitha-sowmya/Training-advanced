package com.assignment;

import java.util.Scanner;

public class TestRectangle {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter length and breadth values");

		
		Rectangle r=new Rectangle();
		r.setLength(sc.nextDouble());
		r.setBreadth(sc.nextDouble());
		System.out.println("Area:"+r.Area());
		System.out.println("Length:"+r.getLength());
		System.out.println("Breadth:"+r.getBreadth());
		System.out.println("Perimeter:"+r.Perimeter());
		
		Rectangle r1=new Rectangle();
		r1.setLength(sc.nextDouble());
		r1.setBreadth(sc.nextDouble());
		System.out.println("Area:"+r1.Area());
		System.out.println("Length:"+r1.getLength());
		System.out.println("Breadth:"+r1.getBreadth());
		System.out.println("Perimeter:"+r1.Perimeter());
		
		Rectangle r2=new Rectangle();
		r2.setLength(sc.nextDouble());
		r2.setBreadth(sc.nextDouble());
		System.out.println("Area:"+r2.Area());
		System.out.println("Length:"+r2.getLength());
		System.out.println("Breadth:"+r2.getBreadth());
		System.out.println("Perimeter:"+r2.Perimeter());
		
		Rectangle r3=new Rectangle();
		r3.setLength(sc.nextDouble());
		r3.setBreadth(sc.nextDouble());
		System.out.println("Area:"+r3.Area());
		System.out.println("Length:"+r3.getLength());
		System.out.println("Breadth:"+r3.getBreadth());
		System.out.println("Perimeter:"+r3.Perimeter());
		
		Rectangle r4=new Rectangle();
		r4.setLength(sc.nextDouble());
		r4.setBreadth(sc.nextDouble());
		System.out.println("Area:"+r4.Area());
		System.out.println("Length:"+r4.getLength());
		System.out.println("Breadth:"+r4.getBreadth());
		System.out.println("Perimeter:"+r4.Perimeter());
		

		
	}

}
