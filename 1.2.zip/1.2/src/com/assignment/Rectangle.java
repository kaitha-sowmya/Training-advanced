package com.assignment;

import java.util.Scanner;

public class Rectangle {
Double length;
Double breadth;
//Scanner sc=new Scanner(System.in);
//n=sc.nextInt();
public Rectangle() {
	super();
	length = (double) 0;
	breadth = (double) 0;
}
public Double getLength() {
	return length;
}
public void setLength(Double length) {
	this.length = length;
}
public Double getBreadth() {
	return breadth;
}
public void setBreadth(Double breadth) {
	this.breadth = breadth;
}
public double Area(){
	return length*breadth;
	
}
public double Perimeter() {
    return 2*length*breadth;
	
}
}
