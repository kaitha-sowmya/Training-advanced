import java.util.HashMap;
import java.util.Scanner;

public class PhoneBook {
	
	public static void main(String[] args) {
		HashMap< String,Integer> map =new HashMap<String,Integer>();
		Scanner sc=new Scanner(System.in);
		map.put("sowmya",1234);
		map.put("rahul",9876);
		map.put("shruti",55567);
		map.put("sreeja",456789);
		
		
		while(true) {
			System.out.println("choose an action 1.add 2.search 3.quit");
			int i=sc.nextInt();
		
			switch(i) {
			
			
				case 1:{

					System.out.println("Enter the name");
					String name=sc.next();
					System.out.println("Enter the mobile number");
					int phone=sc.nextInt();
					map.put( name,phone);
					System.out.println("added");
					System.out.println(map);
					break;
				}
				
				case 2:{
					System.out.println("Enter the name to search");
					String name=sc.next();
					if(map.containsKey(name)) {
						System.out.println("Phone Number"+map.get(name));
						break;
					}
					else {
						System.out.println("not Present");
						break;
					}
				}
				
				case 3:System.exit(0);
			}
			}
		

		

		
		}	

	}
