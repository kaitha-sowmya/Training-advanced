package com.assignment;

import java.util.ArrayList;
import java.util.Scanner;

public class Student{
	
	public static void main(String[] args) {
	
	
		
			ArrayList<String> Student=new ArrayList<>();	
			Student.add("sowmya");
			Student.add("rahul");
			Student.add("shruti");
			Student.add("sreeja");
			
			
			Scanner scanner=new Scanner(System.in);
			
			System.out.println("enter student name");
			String sname;
			sname=scanner.next();
			boolean temp=false;
			
			
			for(String s:Student) {
				if(sname.equals(s)) {
				temp=true;
				break;
				}
			}
			if(temp==true) {
				System.out.println(sname+" is present");
			}
			else {
				System.out.println(sname+ " not found in student list");
			}
		}

	}