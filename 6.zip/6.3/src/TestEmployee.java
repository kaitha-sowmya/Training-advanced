import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

public class TestEmployee {
	LinkedList<Employee> list =new LinkedList<>();

   public static void main(String[] args) {
	TestEmployee te=new TestEmployee();
	te.addInput();
	te.display();
   }
public void display() {
		for(Employee e:list) {
			System.out.println(e.EmployeeNo+" "+e.EmployeeName+" "+e.Address);
		}
		Iterator it=list.iterator();
		System.out.println(" In the forword direction : ");
		while (it.hasNext()) {
	         System.out.println(it.next());
	      }
		ListIterator i = list.listIterator(list.size());
	      System.out.println(" In the reverse direction : ");
	      while (i.hasPrevious()) {
	         System.out.println(i.previous());
	      }
	}



 
    	public void addInput() {
    		
    		int eid;String ename,add;
    		Scanner sc=new Scanner(System.in);
    		System.out.println(" enter nmber of employees");
    		int n=sc.nextInt();
    		for(int i=0;i<n;i++) {
    		System.out.println("Enter Eid");
    		eid=sc.nextInt();
    		System.out.println("Enter Ename");
    		ename=sc.next();
    		System.out.println("Enter Address");
    		add=sc.next();
    		Employee e=new Employee(eid, ename, add);
    	
    		list.add(e);
    		}
    	}
}