import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	HashSet<Product> set = new HashSet<Product>();
	//ArrayList<Product> list1 = new ArrayList<>();
	
	
	Scanner sc=new Scanner(System.in);
	System.out.println("enetr number of products");
	int n=sc.nextInt();
	for(int i=0;i!=n;i++)
	{
		
	System.out.println("enter product id:");
	int id=sc.nextInt();
	System.out.println("enter product Name:");
	String name=sc.next();
	Product p=new Product(id,name);
	
	//list1.add(p);
	set.add(p);
	
}
	for(Product p1:set) {
	System.out.println(p1);
	}
	
	
	String pp;
	System.out.println("enetr product name to search");
	pp=sc.next();
	boolean temp=false;	
	for(Product s:set) {
		
		if(pp.equals(s)) {
		temp=true;
		break;
		}
	}
	if(temp==true) {
		System.out.println(pp+" is present");
	}
	else {
		System.out.println(pp+ " not found in product list");
	}
}
}
