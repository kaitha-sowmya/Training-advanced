import java.util.Scanner;

public class ClimbingStairs {
	    
      static void climbStairs(int n) {
    	  if(1 <= n &&n<= 45) {
		  if (n < 3) System.out.println( n);
		  
		  
		  int first = 1;
		  int second = 2;
		  for (int i = 2; i < n; i++) {
		    int current = first + second;
		    first = second;
		    second = current;
		  }

		  System.out.println("no.of ways :"+second);
    	  }
    	  else {
    		  System.out.println("please enter number between 1 and 46");
    	  }
		}
      public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no.of steps");
		int n=sc.nextInt();
		climbStairs(n);
	}
	}
