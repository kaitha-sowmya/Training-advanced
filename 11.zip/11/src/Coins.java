import java.util.*;


		class Coins
		{
		  
		    // All denominations of Indian Currency 
		    static int coin[] = {1, 2, 5, 10, 20, 
		    50, 100, 500, 1000,2000};
		    static int n = coin.length;
		  
		    static void findMin(int amount)
		    {
		       
		        Vector<Integer> notes = new Vector<>();
		  
		        
		        for (int i = n - 1; i >= 0; i--)
		        {
		            
		            while (amount >= coin[i]) 
		            {
		                amount=amount - coin[i];
		                notes.add(coin[i]);
		            }
		        }
		  
		       
		        for (int i = 0; i < notes.size(); i++)
		        {
		            System.out.print( " " + notes.elementAt(i));
		        }
		    }
		  
		    // Driver code 
		    public static void main(String[] args) 
		    {
		    	Scanner sc=new Scanner(System.in);
		    	System.out.println("enter a number");
		        int n = sc.nextInt();
		        System.out.print("Following is minimal number "+"of change for " + n + ": ");
		        findMin(n);
		    }
		}