package com.assignment;

public class Fibanocci {
	public static void main(String[] args) {
		int count = 13;
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		System.out.print(a+" "+b+" ");
		for (int i = 1; i <= count; ++i) {
			int c=a+b;
			a=b;
			b=c;
			System.out.print(c+" ");
			} 
		} 
	}

