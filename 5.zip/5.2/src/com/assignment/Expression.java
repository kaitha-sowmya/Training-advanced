package com.assignment;

import java.util.StringTokenizer;

public class Expression {

	public static void main(String[] args) {
//		String str="23 +45 - (343 /12 )";  
//		
//		String[] arrOfStr = str.split(" ");
//		 
//        for (String a : arrOfStr)
//            System.out.println(a);

		
		 StringTokenizer st =
		            new StringTokenizer("23 + 45 - ( 343 /   12 )");

		        
		        System.out.println("Tokens count: " + st.countTokens());

		        while (st.hasMoreElements()) {
		            String token = st.nextElement().toString();
		            System.out.println(token);
	}

}}
