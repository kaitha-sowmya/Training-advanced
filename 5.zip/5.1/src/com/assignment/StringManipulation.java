package com.assignment;

import java.util.Scanner;

public class StringManipulation {
public static void main(String[] args) {
	String str="Java IS sIMple";
	String str3[]="java is simple".split(" ");
	String str1=str.toUpperCase();
	System.out.println("uppercase:"+str1);
	
	String str2=str.toLowerCase();
	System.out.println("lowercase:"+str2);
	
	System.out.println("length:"+str.length());
	
	System.out.println(str.charAt(0)+" "+str.charAt(5)+" "+str.charAt(8));
	
	String nstr="";char ch;
	
	for (int i=0; i<str2.length(); i++)
    {
      ch= str2.charAt(i); 
      nstr= ch+nstr; 
    }
	System.out.println("Reversed String:"+nstr);
		
	String ans = "";
    for (int i = str3.length - 1; i >= 0; i--)
    {
        ans += str3[i] + " ";
    }
    System.out.println("Reversed String:");
    System.out.println(ans.substring(0,
                              ans.length() - 1));
	
}
}
