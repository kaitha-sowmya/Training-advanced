
public class Mphasis {
	
		public static String shift(String s, int k){
		    String result=s;  

		    for(int i=0; i<k; i++){
		        result = result.substring(1) + result.charAt(0);
		    }

		    return result;
		}
	public static void main(String[] args) {

		String s="MPHASIS";

		for(int i=0;i<=s.length()-1;i++) {
		System.out.println(shift(s,i));
		}
		System.out.println(s);
		
		}
	}


