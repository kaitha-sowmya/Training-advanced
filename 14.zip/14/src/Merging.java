import java.util.Arrays;
import java.util.Scanner;

public class Merging {
	public static void sortedMerge(int a[], int b[],
            int C[], int n,
            int m)
{

int i = 0, j = 0, k = 0;
while (i < n) {
C[k] = a[i];
i++;
k++;
}

while (j < m) {
C[k] = b[j];
j++;
k++;
}


Arrays.sort(C);
}


public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter Array1 length");
	int x=sc.nextInt();	  
	int[] A = new int[x];
	System.out.println("enter Array1 elements");
	for(int i=0; i<x; i++)  
	{  
	A[i]=sc.nextInt();  
	}  
		
		
	System.out.println("enter Array2 length");
	int y=sc.nextInt();
	int[] B = new int[y];
	System.out.println("enter Array2 elements");
	for(int i=0; i<y; i++)  
	{  
	B[i]=sc.nextInt();  
	}  
int n = A.length;
int m = B.length;


int C[]=new int[n + m];
sortedMerge(A, B, C, n, m);

System.out.print("Sorted merged list :");
for (int i = 0; i < n + m; i++)
System.out.print(" " + C[i]);
}
}


