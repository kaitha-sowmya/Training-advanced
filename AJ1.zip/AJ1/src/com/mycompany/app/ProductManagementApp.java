package com.mycompany.app;


		import java.sql.SQLException;
import java.util.Scanner;

		import com.mycompany.dao.ProductManagementDAO;
		import com.mycompany.domain.Product;

		public class ProductManagementApp {
		public static void main(String[] args) throws ClassNotFoundException, SQLException {
			Scanner sc=new Scanner(System.in);
			Product p=new Product();
			ProductManagementDAO dao=new ProductManagementDAO();
			int g;
			System.out.println("PRODUCT MANAGEMENT");
			System.out.println();
			
		try {
			
			while (true) {
				System.out.println("1.View Products\n2.ADD Product\n3.Update Product\n4.Delete Product\n5.Search Product\n6.Exit");
				System.out.println("*****************************");
				System.out.println("Choose an option");
				System.out.println("*****************************");
				g=sc.nextInt();
				switch(g) {
                     case 1:{
					
					dao.display();
					break;
                     }
				case 2:{
					System.out.println("Enter Productid");
					p.setPid(sc.next());
					System.out.println("Enter Productname");
					p.setPname(sc.next());
					System.out.println("Enter Price");
					p.setPrice(sc.nextInt());
					
					int m=dao.insert(p);
					if(m>0) {
						System.out.println("insertion successfull");
					}
					else {
						System.out.println("insertion failed");
					}
					break;
				}
				case 3:{
					System.out.println("Enter Product Name");
					p.setPname(sc.next());
					System.out.println("Enter Product Price");
					p.setPrice(sc.nextInt());
					System.out.println("Enter Product ID");
					p.setPid(sc.next());
					int s=dao.update(p);
					if(s>0) {
						System.out.println("Updation successfull");
					}
					else {
						System.out.println("Updation Failed");
					}
					break;
				}
				
	             case 4:{
					System.out.println("Enter Product Id");
					p.setPid(sc.next());
					int q=dao.delete(p);
				    if(q>0)
				           {		
					         System.out.println("Deletion Sucessfull");
				           }

				      else 
				        {		
					       System.out.println("Deletion failed");

				         }
					break;
				}
	             case 5:{
						
						System.out.println("Enter Product Id");
						p.setPid(sc.next());
						dao.search(p);
						break;
					}
				case 6:
					System.out.println("Thank You!!");
					System.exit(0);
				
				}
				
			
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
			
		}
		}
