create database bookstore;
use bookstore;




create table Books (Book_Id int primary key, Book_Name varchar(300), Author varchar(300), Price int(200));
insert into books values(1,'Let us c','Yashvant p',200);
insert into books values(2,'Thinking in Java','Thinking in Java',300);
insert into books values(3,'Computer Networking','James F. Kurose',250);
insert into books values(4,'Head First C#','Andrew Stellman',400);
insert into books values(5,'What is HTML5','Brett McLaughli',300);
insert into books values(6,'HTML5 in action','Joe Lennon',569);
insert into books values(7,'OOP With C++','Balaguruswamy',308);
insert into books values(8,'C++:The Complete Reference','Herbert Scheledt',532);
insert into books values(9,'Head First SQL','Lynn Beighly',450);
insert into books values(10,'SQL:The Complete Reference','James Groff',667);


select * from Books;

desc users;
drop table users; 
create table Users (first_name varchar(300), address varchar(300), email varchar(300), user_name varchar(300) ,
 password varchar(300), registration_date date);
insert into users values('Amit','Wagholi',
'amit.mishra@gmail.com',9673960407,'mona9Dutta',sysdate());
insert into users values('Hari','Chandan Nagar',
'hari39@rediff.com',7845127421,'Adam99@',sysdate());
insert into users values('Monalisa','Rakshak Nagar',
'mona9@gmail.com',9878454503,'pinaki9@',sysdate());
insert into users values('Narendra','Rajpath',
'narendra17@pmo.nic.in',8877990011,'Delhi9%',sysdate());
insert into users values('Kavita','Rakshak Nagar Gold',
'kavi23@gmail.com',9878521402,'Alia&&',sysdate());


select * from users;







drop table Order_Details;
create table Order_Details (Order_Id int primary key,Address varchar(256),  Phone_No long,Cust_Name varchar(256), Order_Date date, Quantity int);
 
 insert into Order_Details values(1,'Radhika Vihar',9673960407,'Amit',sysdate(),3);
  insert into Order_Details values(2,'Rakshak Nagar', 875451395,'Mona',sysdate(),3);
  insert into Order_Details values(3,'Rakshak Nagar Gold',7845127845,'Kavi',sysdate(),2);
  insert into Order_Details values(4,'Banglore', 784512788,'Monalisa',sysdate(),3);
  insert into Order_Details values(5,'Wadganosheri',784578215,'Amol',sysdate(),3);
  insert into Order_Details values(6,'Banglore',78521868,'Amit',sysdate(),2);
 select * from Order_Details;
 
 
 
 