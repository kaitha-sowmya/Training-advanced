

public class MedicineInfo
{
public void displayLabel()
{
System.out.println("CompanyName : Medicare");
System.out.println("Address : Hyderabad");
}
}
class Tablet extends MedicineInfo
{
public void displayLabel()
{
System.out.println("store in a cool dry place");
}
}
class Syrup extends MedicineInfo
{
public void displayLabel()
{
System.out.println("sell only if prescribed");
}
}
class Ointment extends MedicineInfo
{
public void displayLabel()
{
System.out.println("for external use only");
}
}


