import java.util.Scanner;

public class TestMedicine {

public static void main(String[] args)
{
MedicineInfo mi[] = new MedicineInfo[10];
double i = Math.random()*4;
int j = (int) i;
System.out.println(j);

switch(j)
{
case 1: mi[0] = new MedicineInfo();
mi[1] = new Tablet();
mi[0].displayLabel();
mi[1].displayLabel();
break;
case 2: mi[2] = new MedicineInfo();
mi[3] = new Syrup();
mi[2].displayLabel();
mi[3].displayLabel();
break;
case 3: mi[4] = new MedicineInfo();
mi[5] = new Ointment();
mi[4].displayLabel();
mi[5].displayLabel();
break;
default: System.out.println("Enter valid choice");
}
}
}