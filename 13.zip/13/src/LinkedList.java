import java.util.Scanner;

class LinkedList {
    Node head;
    class Node {
        int data;
        Node next;
        Node(int d)
        {
            data = d;
            next = null;
        }
    }
    
 
    
    void printNthFromLast(int n)//4
    {
    	 Node main_ptr = head;
         Node ref_ptr = head;
  
         int count = 0;
         if (head != null)
         {
             while (count <= n)//0<4 1<4 2<4 3<4
             {
                 if (ref_ptr == null)
                 {
                     System.out.println(n
                      + " is greater than the no "
                        + " of nodes in the list");
                     return;
                 }
                 ref_ptr = ref_ptr.next;//*3 //*4 //*6 //*8
                 count++;
             }
  
             if(ref_ptr == null)
             {
               
               if(head != null)
                 System.out.println("Node no.from last is " +
                                       head.data);
             }
             else
             {
                    
               while (ref_ptr != null)
               {
                   main_ptr = main_ptr.next;
                   ref_ptr = ref_ptr.next;
               }
               System.out.println("Node no. " + n+
                                 " from last is " +
                                   main_ptr.data);
             }
         }
     }
    
    
 
    
    public void push(int new_data)
    {
        Node new_node = new Node(new_data);
        new_node.next = head;
        head = new_node;
    }
 
   
    public static void main(String[] args)
    {
        LinkedList llist = new LinkedList();
      Scanner sc=new Scanner(System.in);
      System.out.println("enter length of list");
      int n=sc.nextInt();
      System.out.println("enter elements into list");
      for(int i=0;i<n;i++) {
       
      int p=sc.nextInt();
        llist.push(p);
     
      }
      
      System.out.println("enter nth node from end");
      int end=sc.nextInt();
        llist.printNthFromLast(n-end);
    }
}