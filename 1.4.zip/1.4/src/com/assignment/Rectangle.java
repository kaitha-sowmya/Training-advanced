package com.assignment;



import java.util.Scanner;

public class Rectangle {
Float length;
Float breadth;
//Scanner sc=new Scanner(System.in);
//n=sc.nextInt();
public Rectangle() {
	super();
	length = 1F;
	breadth = 1F;
}
public void getLength() {
	System.out.println("length:"+length);
}
public void setLength(Float length) {
	if(length>0.0&&length<20.0) {
	this.length = length;
	}
	else {
		System.out.println("enter between 1.0 and 20.0");
	}
}
public void getBreadth() {
	System.out.println("breadth:"+breadth);
}
public void setBreadth(Float breadth) {
	if(breadth>0.0&&breadth<20.0) {
	this.breadth = breadth;
	}
	else {
		System.out.println("enter between 1.0 and 20.0");
	}
}
public void Area(){
	System.out.println("Area:"+length*breadth);
	
}
public void Perimeter() {
   System.out.println("perimeter:"+2*length*breadth);
	
}
}
