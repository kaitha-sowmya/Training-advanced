package com.assignment;

import java.util.Scanner;

public class TestRectangle {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter length and breadth values");
		
		Rectangle r=new Rectangle();
		r.setLength(sc.nextFloat());
		r.setBreadth(sc.nextFloat());
		
		r.getLength();
		r.getBreadth();
	
		r.Perimeter();
		r.Area();
}
}