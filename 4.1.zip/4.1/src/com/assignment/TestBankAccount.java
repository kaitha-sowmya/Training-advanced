package com.assignment;

public class TestBankAccount {

	public static void main(String[] args) throws Exception {
		BankAccount b=new BankAccount(1,"sowmya", "current",10000);
		System.out.println("account number:"+b.getAccNo());
		System.out.println("account Type: "+b.getAccType());
		System.out.println("customer Name: "+b.getCustName());
		System.out.println("account balance: "+b.getBalance());
		b.deposit(100);
        b.withdraw(200);
        System.out.println("Total Balance: "+b.getBalance());
        System.out.println();
        
        BankAccount b1=new BankAccount(2,"Rahul", "savings",500);
        System.out.println("account number:"+b1.getAccNo());
		System.out.println("account Type: "+b1.getAccType());
		System.out.println("customer Name: "+b1.getCustName());
		System.out.println("account balance: "+b1.getBalance());
		b1.deposit(100);
        b1.withdraw((float) 200.0);
        System.out.println("Total Balance: "+b1.getBalance());
	}

}
