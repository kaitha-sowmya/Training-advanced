package com.assignment;

public class BankAccount {
int accNo;
String custName;
String accType;
float balance;

public BankAccount(int accNo, String custName, String accType, float balance) {
	super();
	this.accNo = accNo;
	this.custName = custName;
	this.accType = accType;
	this.balance = balance;
}

public int getAccNo() {
	return accNo;
}

public void setAccNo(int accNo) {
	this.accNo = accNo;
}

public String getCustName() {
	return custName;
}

public void setCustName(String custName) {
	this.custName = custName;
}

public String getAccType() {
	return accType;
}

public void setAccType(String accType) {
	this.accType = accType;
}

public void setBalance(float balance) {
	this.balance = balance;
}

public void deposit(float amt) throws Exception {
	if(balance>0) {
		balance=balance+amt;
		System.out.println("successfully deposited "+amt);
	}
	else {
		throw new Exception("NegativeAmount");
	}
	
}
public void withdraw(float amt) throws Exception {
	if(balance>1000&&accType=="savings") {
     balance=balance-amt;
     System.out.println("successfully withdrawed "+amt);
	}
	else if(accType=="current"&&balance>5000){
		balance=balance-amt;
		System.out.println("successfully withdrawed "+amt);
	}
	else {
		throw new Exception("InsufficientFunds!!");
	}
}
public float getBalance(){
	return balance;

}

}
