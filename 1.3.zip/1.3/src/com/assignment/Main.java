package com.assignment;

import java.util.Scanner;

public class Main {
	  public static  int n;
	  public static  Book bookobj[]=new Book[n];
	    public static void main(String[] args) {
	    	Scanner sc=new Scanner(System.in);
			
	        System.out.println("enter no.of books");
	          n=sc.nextInt();
		createbook();
		showbook();
			
		}
	
	private static void createbook() {

         Scanner sc=new Scanner(System.in);
//		
//        System.out.println("enter no.of books");
//          n=sc.nextInt();
//		Book bookobj[]=new Book[n];
		
		for(int i=0;i<2;i++) {
			bookobj[i]= new Book();
			System.out.println("enter book title");
			bookobj[i].setBooktitle(sc.next());
			System.out.println("enter book price");
			bookobj[i].setBookprice(sc.nextInt());
			System.out.println(bookobj[i].getBookprice());
			System.out.println(bookobj[i].getBooktitle());
		}
		
		
		}
	private static void showbook() {
		for(int i=0;i<n;i++) {
		System.out.println(bookobj[i].toString());
		}
	}
	}

