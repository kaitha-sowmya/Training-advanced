package com.assignment;

public class Book {
String booktitle;
int bookprice;

public Book() {
	super();
	this.booktitle = booktitle;
	this.bookprice = bookprice;
}
public String getBooktitle() {
	return booktitle;
}
public void setBooktitle(String booktitle) {
	this.booktitle = booktitle;
}
public int getBookprice() {
	return bookprice;
}
public void setBookprice(int bookprice) {
	this.bookprice = bookprice;
}
@Override
public String toString() {
	return "Book [booktitle=" + booktitle + ", bookprice=" + bookprice + "]";
}

}
