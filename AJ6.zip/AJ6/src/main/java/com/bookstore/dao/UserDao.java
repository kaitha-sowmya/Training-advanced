package com.bookstore.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bookstore.bean.*;
import com.bookstore.dbcon.Dbconnection;
public class UserDao {
	

	
		public static int insert(User u) throws ClassNotFoundException, SQLException {
			String sql="insert into users(first_name,address,Email,user_name,password,registration_date) values(?,?,?,?,?,?)";
			Connection con=Dbconnection.Dbcon();
	        PreparedStatement ps=con.prepareStatement(sql);
	        ps.setString(1,u.getFname());
	        ps.setString(2,u.getAddress());
	        ps.setString(3,u.getEmail());
	        ps.setString(4,u.getUsername());
	        ps.setString(5,u.getPassword());
	        ps.setString(6,java.time.LocalDate.now().toString());
	        return ps.executeUpdate();
		}
		public static ResultSet search() throws ClassNotFoundException, SQLException {
			String sql="select user_name,password from users";
			Connection con=Dbconnection.Dbcon();
	        PreparedStatement ps=con.prepareStatement(sql);
	        return ps.executeQuery();
		}
		
		public static int Updatepassword(User u) throws ClassNotFoundException, SQLException {
			String sql="update users set password=? where email=?";
			Connection con=Dbconnection.Dbcon();
	        PreparedStatement ps=con.prepareStatement(sql);
	        ps.setString(1,u.getPassword());
	        ps.setString(2, u.getEmail());
	        return ps.executeUpdate();
			
		}
		
		public static ResultSet select() throws ClassNotFoundException, SQLException {
			String sql="select email,user_name from users";
			Connection con=Dbconnection.Dbcon();
	        PreparedStatement ps=con.prepareStatement(sql);
	        return ps.executeQuery();
		}
		


	}


