package com.bookstore.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bookstore.bean.Books;
import com.bookstore.dbcon.*;

public class Bookdao {
	
		

	  public ResultSet display() throws ClassNotFoundException, SQLException {
		  String sql="select * from Books";
		  Connection con=Dbconnection.Dbcon();
		 PreparedStatement ps=con.prepareStatement(sql);
		 return ps.executeQuery();
		  
	  }
	  public static ResultSet select(Books b) throws ClassNotFoundException, SQLException {
		  String sql="select * from Books where book_id=?";
		  Connection con=Dbconnection.Dbcon();
		 PreparedStatement ps=con.prepareStatement(sql);
		 ps.setInt(1, b.getId());
		 return ps.executeQuery();
	  }

	}


