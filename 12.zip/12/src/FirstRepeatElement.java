import java.io.*;
import java.util.Scanner;
public class FirstRepeatElement {
	
	
	    public static int firstRepeated(int[] arr, int n)
	    {
	        int max = 0;
	        for (int i = 0; i < n; i++) {
	            if (arr[i] > max) {
	                max = arr[i];
	            }
	        }
	        int temp[]= new int[max + 1]; 
	 
	        for (int i = 0; i < n;i++) {
	            int num = arr[i];
	            temp[num]++;
	        }
	 
	        for (int i = 0; i < n; i++) {
	            int num = arr[i];
	            if (temp[num] > 1) {
	                return i;
	            }
	        }
	 
	        return -1; 
	    }
	    public static void main(String[] args)
	    {
	    	Scanner sc=new Scanner(System.in);
	    	System.out.println("enter array length");
	    	int x=sc.nextInt();	  
	    	
	    	int[] arr = new int[x];
	    	System.out.println("enter array elements");
	    	for(int i=0; i<x; i++)  
	    	{  
	    	arr[i]=sc.nextInt();  
	    	}  
	        
	 
	        int n = arr.length;
	        int index = firstRepeated(arr,arr.length); 
	        if (index != -1) {
	            System.out.println("First Repeating Number: "+ arr[index]);
	        }
	        else {
	            System.out.println("There's no repeating number ");
	        }
	    }
	}

