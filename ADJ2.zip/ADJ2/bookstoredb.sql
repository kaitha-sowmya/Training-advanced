create database bookstore;
use bookstore;

create table Books (Book_Id int primary key, Book_Name varchar(300), Author varchar(300), Price int(200));

create table Users (first_name varchar(300), address varchar(300), email varchar(300), user_name varchar(300) , password varchar(300), registration_date date);
create table Order_Details (Order_Id int primary key,book_Id int, Cust_Name varchar(256), 
Phone_No long, Address varchar(256), Order_Date date, Quantity int);