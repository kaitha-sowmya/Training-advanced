package com.assignment;

public class Array {
public static void main(String[] args) {
	int[] a = new int[args.length];
	int avg=0;
	int count=0;
	for (int i = 0; i < args.length; i++) {
	    a[i] = Integer.parseInt(args[i]);
	    System.out.print(a[i]+" ");
	}
	
	for(int i=0;i<15;i++) {
		a[15]=a[15]+a[i];
		
	}
	System.out.println();
	System.out.println("15th :"+a[15]);
	
	for(int i=0;i<16;i++) {
		avg=avg+a[i];
	}
	int totalavg=avg/2;
	a[16]=totalavg;
	System.out.println("16th :"+ a[16]);
	
	for(int i=0;i<=args.length-1;i++) {
		for(int j=1;j<=args.length-1;j++) {
			if(a[i]>a[j]) {
				count=a[j];
				a[17]=a[j];
			}
			else {
				count=a[i];
				a[17]=a[i];
			}
		}
		
	}
System.out.println("smallest:"+count);
System.out.println("17th :"+a[17]);
}
}

